import sqlite3

# Connect to the database
conn = sqlite3.connect("football.db")
cursor = conn.cursor()

# Create tables
cursor.execute('''CREATE TABLE IF NOT EXISTS players (
    id INTEGER PRIMARY KEY,
    name TEXT,
    clubs TEXT,
    stats TEXT
)''')

cursor.execute('''CREATE TABLE IF NOT EXISTS clubs (
    id INTEGER PRIMARY KEY,
    name TEXT,
    history TEXT,
    achievements TEXT
)''')

# Add a sample player
cursor.execute("INSERT INTO players (name, clubs, stats) VALUES (?, ?, ?)", 
               ("Zlatan Ibrahimović", "Juventus, Inter Milan, Barcelona, AC Milan, PSG, Man United, LA Galaxy, AC Milan", "Goals: 500+"))
conn.commit()

# Function to search for a player
def search_player(name):
    cursor.execute("SELECT * FROM players WHERE name=?", (name,))
    result = cursor.fetchone()
    return result if result else "Player not found"

if __name__ == "__main__":
    print(search_player("Zlatan Ibrahimović"))
