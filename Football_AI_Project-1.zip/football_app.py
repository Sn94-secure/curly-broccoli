import streamlit as st
from football_db import search_player
from fetch_live_data import get_team_info
from ai_predictions import model
import pandas as pd

st.title("⚽ Football AI - Ask Anything About Football!")

# Player Search
st.header("🔍 Search for a Player")
player_name = st.text_input("Enter Player Name")
if st.button("Search"):
    result = search_player(player_name)
    if result != "Player not found":
        st.write(f"**Name:** {result[1]}")
        st.write(f"**Clubs Played:** {result[2]}")
        st.write(f"**Stats:** {result[3]}")
    else:
        st.write("Player not found in the database.")

# Live Team Data
st.header("🌍 Get Live Team Info")
team_id = st.text_input("Enter Team ID (e.g., 64 for Arsenal)")
if st.button("Get Team Info"):
    team_data = get_team_info(int(team_id))
    st.write(team_data)

# AI Predictions
st.header("📊 Predict Future Player Performance")
seasons = [[2023], [2024], [2025]]
predictions = model.predict(seasons)
df = pd.DataFrame({"Season": [2023, 2024, 2025], "Predicted Goals": predictions})
st.write(df)

st.write("Built with ❤️ using Python & AI")
