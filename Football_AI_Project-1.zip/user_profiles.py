import sqlite3

# Connect to the database
conn = sqlite3.connect("football.db")
cursor = conn.cursor()

# Create users table
cursor.execute('''CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    name TEXT,
    favorite_team TEXT
)''')

# Add a sample user
cursor.execute("INSERT INTO users (name, favorite_team) VALUES (?, ?)", 
               ("John", "Manchester United"))
conn.commit()

if __name__ == "__main__":
    print("User profile created!")
