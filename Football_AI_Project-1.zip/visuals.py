import matplotlib.pyplot as plt

seasons = [2018, 2019, 2020, 2021, 2022]
goals = [10, 15, 20, 22, 30]

plt.plot(seasons, goals, marker="o")
plt.title("Player Goals Over Seasons")
plt.xlabel("Season")
plt.ylabel("Goals")
plt.show()
