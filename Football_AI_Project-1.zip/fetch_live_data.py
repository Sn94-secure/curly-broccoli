import requests

API_URL = "https://api.football-data.org/v4/teams"  # Example API
API_KEY = "your_api_key_here"  # Replace with your real API key

def get_team_info(team_id):
    headers = {"X-Auth-Token": API_KEY}
    response = requests.get(f"{API_URL}/{team_id}", headers=headers)
    return response.json()

# Example usage
if __name__ == "__main__":
    team_data = get_team_info(64)  # Arsenal's ID
    print(team_data)
