import pandas as pd
from sklearn.linear_model import LinearRegression

# Sample player data (goals per season)
data = {
    "season": [2018, 2019, 2020, 2021, 2022],
    "goals": [10, 15, 20, 22, 30]
}

df = pd.DataFrame(data)

# Train the model
model = LinearRegression()
model.fit(df[["season"]], df["goals"])

# Predict future goals
next_season = 2023
predicted_goals = model.predict([[next_season]])

if __name__ == "__main__":
    print(f"Predicted goals in {next_season}: {int(predicted_goals[0])}")
