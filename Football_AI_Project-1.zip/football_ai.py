from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate

# Set up the AI model
api_key = "your_openai_api_key"  # Replace this with your real OpenAI API key
llm = OpenAI(model_name="gpt-4", openai_api_key=api_key)

# Create a prompt template
template = PromptTemplate(
    input_variables=["question"],
    template="You are a football expert. Answer this question: {question}"
)

# Function to get an AI answer
def ask_football_ai(question):
    return llm(template.format(question=question))

# Example usage
if __name__ == "__main__":
    question = "Where has Zlatan played since 2005?"
    print(ask_football_ai(question))
